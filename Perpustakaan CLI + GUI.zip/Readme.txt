Terdapat 2 File:

1. Versi CLI

2. Versi GUI

Pada saat presentasi program, yang berhasil dijalankan sesuai fungsinya adalah program CLI, sedangkan versi GUI mengalami kendala saat memasukkan data.

Kami mengupload kedua program sesuai instruksi terakhir.

Catatan: versi GUI sudah mengalami banyak peningkatan.

Terima Kasih